//
//  ViewController.swift
//  TableViewDemo
//
//  Created by Kondle,Rohith Reddy on 3/29/22.
//

import UIKit

class Product {
    var productsName : String?
    var productCategory : String?
    
    init(productsName : String, productCategory :String){
        self.productsName = productsName
        self.productCategory = productCategory
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
        return productsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //Create a cell and assign a data
        var cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "resuableCell", for: indexPath)
        
        //populate a data
        cell.textLabel?.text = productsArray[indexPath.row].productsName
        
        
        
        //return a cell
        return cell;
    
    }
    
    // Creating an empty products array
    var productsArray = [Product]()
    
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        
        let product1 = Product(productsName: "Mac Book Air", productCategory: "Laptop")
        productsArray.append(product1)
        
        let product2 = Product(productsName: "Iphone", productCategory: "Moboile Phone")
        productsArray.append(product2)
        
        let product3 = Product(productsName: "ipods", productCategory: "accessories")
        productsArray.append(product3)
        
        let product4 = Product(productsName: "Watch", productCategory: "i accessory")
        productsArray.append(product4)
        
        let product5 = Product(productsName: "Air tag", productCategory: "i accessory")
        productsArray.append(product5)
    }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        
        if transition == "detailsSegue" {
            let destination = segue.destination as! DetailsViewController
            
            destination.product = productsArray[(tableViewOutlet.indexPathForSelectedRow?.row)!]
            
            
            
            
        }
    }

}

